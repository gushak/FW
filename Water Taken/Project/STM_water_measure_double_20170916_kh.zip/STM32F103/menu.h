#ifndef _MENU_H_
#define _MENU_H_

extern void setting_mode(void);
extern void SW_check(void);
extern void menu_list();
extern void DW_menu(void);

#endif
