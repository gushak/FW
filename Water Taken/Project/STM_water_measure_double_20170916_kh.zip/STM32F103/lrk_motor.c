#include "hw_control.h"

#define OPEN_MOTOR	0

//extern volatile uint16_t FET_value[10];

volatile uint8_t Input_value[2]={0,};
volatile uint8_t inx = 0;

















