#ifndef __LRK_MOTOR_H__
#define __LRK_MOTOR_H__

extern void Gate_close();
extern void Gate_open(uint16_t m_cnt);
extern void loop_input_check();

#endif