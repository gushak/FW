#ifndef _LORA_PARSE_H_
#define _LORA_PARSE_H_

void Send_ok_data_save(void);
void Send_lora_packet(void);
void Sub_lora_process(void);

#endif

